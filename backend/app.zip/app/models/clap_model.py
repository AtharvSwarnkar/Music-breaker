"""Lazy, process-wide loader for the pretrained CLAP model.

Importing the FastAPI app does not download model weights. The first real
analysis loads the model; tests can inject a lightweight fake detector/model.
"""
from __future__ import annotations

import threading
from typing import Optional


class CLAPModelLoader:
    MODEL_ID = "laion/clap-htsat-unfused"

    def __init__(self, model=None, processor=None, device: Optional[str] = None):
        self.model = model
        self.processor = processor
        self.device = device
        self._lock = threading.Lock()

    def load(self):
        if self.model is not None and self.processor is not None:
            return self
        with self._lock:
            if self.model is None or self.processor is None:
                try:
                    import torch
                    from transformers import ClapModel, ClapProcessor
                except ImportError as exc:
                    raise RuntimeError(
                        "CLAP dependencies are missing. Install backend/requirements.txt "
                        "in the active Python environment."
                    ) from exc
                self.device = self.device or ("cuda" if torch.cuda.is_available() else "cpu")
                self.processor = ClapProcessor.from_pretrained(self.MODEL_ID)
                self.model = ClapModel.from_pretrained(self.MODEL_ID).to(self.device)
                self.model.eval()
        return self


clap_model = CLAPModelLoader()
