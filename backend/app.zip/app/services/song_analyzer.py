from app.feature_extraction.audio.windowing import AudioWindowGenerator
from app.feature_extraction.instrument.detector import InstrumentDetector


class SongAnalyzer:
    def __init__(self, generator=None, detector=None, batch_size=16):
        self.generator = generator or AudioWindowGenerator()
        self.detector = detector or InstrumentDetector()
        self.batch_size = max(1, int(batch_size))

    def analyze(self, audio_path: str):
        windows = self.generator.generate(audio_path)
        analysis = []
        for batch_start in range(0, len(windows), self.batch_size):
            batch = windows[batch_start:batch_start + self.batch_size]
            batch_scores = self.detector.detect_batch(batch)
            if len(batch_scores) != len(batch):
                raise RuntimeError("Detector returned a different number of results than input windows.")
            for offset, scores in enumerate(batch_scores):
                index = batch_start + offset
                analysis.append({
                    "window": index,
                    "start_time": float(index),
                    "end_time": float(index + 1),
                    "scores": scores,
                })
        return analysis
