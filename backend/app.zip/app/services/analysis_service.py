from app.services.song_analyzer import SongAnalyzer
from app.services.analysis_engine import AnalysisEngine


class AnalysisService:
    def __init__(self, song_analyzer=None):
        self.song_analyzer = song_analyzer or SongAnalyzer()

    def analyze(self, audio_path):
        analysis = self.song_analyzer.analyze(audio_path)
        engine = AnalysisEngine(analysis)
        return {
            "analysis": analysis,
            "timelines": engine.get_timelines(),
            "presence": engine.get_presence(),
            "contribution": engine.get_contribution(),
            # Frontend normalizeAnalysis() recognises this summary field.
            "instrument_contribution": engine.get_contribution(),
            "score_semantics": "Independent instrument match score (0-1), not a calibrated probability or physical mix contribution.",
        }
