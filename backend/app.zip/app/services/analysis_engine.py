"""Aggregate per-window instrument match scores without false normalization."""
from __future__ import annotations


class AnalysisEngine:
    def __init__(self, analysis):
        self.analysis = analysis or []

    def normalize_scores(self):
        # Scores are independent match indices in [0, 1], not a probability
        # distribution. Do not divide by the sum: that creates false positives.
        normalized = []
        for window in self.analysis:
            scores = window.get("scores", {})
            clean = {key: max(0.0, min(1.0, float(value))) for key, value in scores.items()}
            normalized.append({
                "window": int(window.get("window", len(normalized))),
                "start_time": float(window.get("start_time", len(normalized))),
                "end_time": float(window.get("end_time", len(normalized) + 1)),
                "scores": clean,
            })
        return normalized

    def get_timelines(self):
        timelines = {}
        for window in self.normalize_scores():
            for instrument, score in window["scores"].items():
                timelines.setdefault(instrument, []).append(score)
        return timelines

    def get_presence(self, threshold=0.5):
        normalized = self.normalize_scores()
        if not normalized:
            return {}
        instruments = normalized[0]["scores"]
        return {
            instrument: round(100 * sum(w["scores"].get(instrument, 0) >= threshold for w in normalized) / len(normalized), 2)
            for instrument in instruments
        }

    def get_contribution(self):
        normalized = self.normalize_scores()
        if not normalized:
            return {}
        instruments = normalized[0]["scores"]
        contribution = {
            instrument: round(sum(w["scores"].get(instrument, 0.0) for w in normalized) / len(normalized), 4)
            for instrument in instruments
        }
        return dict(sorted(contribution.items(), key=lambda item: item[1], reverse=True))
